# IPTV Player - Android App

একটি সম্পূর্ণ IPTV Android অ্যাপ যা M3U playlist সাপোর্ট করে।

## Features
- ✅ M3U/M3U8 playlist (URL এবং local file)
- ✅ Live TV channel list with group/category tabs
- ✅ ExoPlayer দিয়ে HLS, RTSP, HTTP stream playback
- ✅ Favorites (⭐) toggle
- ✅ Channel search
- ✅ Picture-in-Picture (PiP) mode
- ✅ Room database — offline channel storage
- ✅ Pull-to-refresh playlist
- ✅ Dark/Light theme support

## Project Structure
```
app/
├── data/
│   ├── db/          — Room database, DAO
│   ├── model/       — Channel, Playlist entities
│   ├── parser/      — M3U parser
│   └── repository/  — PlaylistRepository
└── ui/
    ├── splash/      — Splash screen
    ├── main/        — MainActivity + ViewModel
    ├── playlist/    — Playlist list + Add playlist
    ├── channels/    — Channel list with group tabs
    ├── favorites/   — Favorite channels
    ├── search/      — Search channels
    └── player/      — ExoPlayer fullscreen player
```

## Android Studio তে Open করতে
1. Android Studio খুলুন
2. **File → Open** → এই ফোল্ডার select করুন
3. Gradle sync হতে দিন
4. Run করুন (minSdk 21, targetSdk 34)

## M3U Playlist যোগ করতে
1. অ্যাপ চালু করুন → **+** বাটনে ক্লিক করুন
2. নাম দিন (যেমন: "My IPTV")
3. M3U URL দিন (যেমন: `http://example.com/playlist.m3u`)
4. **Add** চাপুন — channels automatically load হবে

## Dependencies
- androidx.media3 (ExoPlayer) — video playback
- Room — local database
- Glide — channel logo loading
- OkHttp — M3U download
- Material Components — UI
