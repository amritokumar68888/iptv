package com.iptvplayer.app.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.iptvplayer.app.R
import com.iptvplayer.app.databinding.ActivityMainBinding
import com.iptvplayer.app.ui.channels.ChannelsFragment
import com.iptvplayer.app.ui.favorites.FavoritesFragment
import com.iptvplayer.app.ui.playlist.PlaylistFragment
import com.iptvplayer.app.ui.search.SearchFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBottomNavigation()

        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(PlaylistFragment())
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_playlists -> { loadFragment(PlaylistFragment()); true }
                R.id.nav_channels  -> { loadFragment(ChannelsFragment()); true }
                R.id.nav_favorites -> { loadFragment(FavoritesFragment()); true }
                R.id.nav_search    -> { loadFragment(SearchFragment()); true }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
