package com.iptvplayer.app.ui.playlist

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.iptvplayer.app.R
import com.iptvplayer.app.databinding.ActivityAddPlaylistBinding
import com.iptvplayer.app.ui.main.MainViewModel

class AddPlaylistActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddPlaylistBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddPlaylistBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.apply {
            title = getString(R.string.add_playlist)
            setDisplayHomeAsUpEnabled(true)
        }

        binding.btnAdd.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            val url  = binding.etUrl.text.toString().trim()

            if (name.isEmpty()) {
                binding.tilName.error = getString(R.string.error_name_required)
                return@setOnClickListener
            }
            if (url.isEmpty()) {
                binding.tilUrl.error = getString(R.string.error_url_required)
                return@setOnClickListener
            }

            binding.progressBar.visibility = View.VISIBLE
            binding.btnAdd.isEnabled = false

            viewModel.addPlaylist(name, url) { result ->
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    binding.btnAdd.isEnabled = true
                    if (result.isSuccess) {
                        Toast.makeText(this, getString(R.string.playlist_added), Toast.LENGTH_SHORT).show()
                        finish()
                    } else {
                        Toast.makeText(this, getString(R.string.error_loading_playlist, result.exceptionOrNull()?.message), Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
