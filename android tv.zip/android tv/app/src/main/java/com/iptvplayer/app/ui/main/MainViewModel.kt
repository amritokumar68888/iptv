package com.iptvplayer.app.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.iptvplayer.app.data.db.AppDatabase
import com.iptvplayer.app.data.model.Channel
import com.iptvplayer.app.data.model.Playlist
import com.iptvplayer.app.data.repository.PlaylistRepository
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    val repository = PlaylistRepository(db.playlistDao(), db.channelDao())

    val playlists = repository.allPlaylists
    val favorites = repository.getFavoriteChannels()

    private var _selectedPlaylistId: Long = -1
    val selectedPlaylistId get() = _selectedPlaylistId

    fun selectPlaylist(id: Long) {
        _selectedPlaylistId = id
    }

    fun getChannelsByPlaylist(playlistId: Long) = repository.getChannelsByPlaylist(playlistId)
    fun getGroupsByPlaylist(playlistId: Long) = repository.getGroupsByPlaylist(playlistId)
    fun getChannelsByGroup(playlistId: Long, group: String) = repository.getChannelsByGroup(playlistId, group)
    fun searchChannels(query: String) = repository.searchChannels(query)

    fun addPlaylist(name: String, url: String, isLocal: Boolean = false, onResult: (Result<Long>) -> Unit) {
        viewModelScope.launch {
            val result = repository.addPlaylist(name, url, isLocal)
            onResult(result)
        }
    }

    fun refreshPlaylist(playlist: Playlist, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = repository.refreshPlaylist(playlist)
            onResult(result)
        }
    }

    fun deletePlaylist(playlist: Playlist) {
        viewModelScope.launch {
            repository.deletePlaylist(playlist)
        }
    }

    fun toggleFavorite(channel: Channel) {
        viewModelScope.launch {
            repository.toggleFavorite(channel)
        }
    }
}
