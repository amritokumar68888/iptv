package com.iptvplayer.app.ui.channels

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.google.android.material.tabs.TabLayout
import com.iptvplayer.app.databinding.FragmentChannelsBinding
import com.iptvplayer.app.data.model.Channel
import com.iptvplayer.app.ui.main.MainViewModel
import com.iptvplayer.app.ui.player.PlayerActivity

class ChannelsFragment : Fragment() {

    private var _binding: FragmentChannelsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var channelAdapter: ChannelAdapter

    private var playlistId: Long = -1
    private var playlistName: String = ""
    private var selectedGroup: String = ALL_CHANNELS

    companion object {
        private const val ARG_PLAYLIST_ID = "playlist_id"
        private const val ARG_PLAYLIST_NAME = "playlist_name"
        private const val ALL_CHANNELS = "All"

        fun newInstance(playlistId: Long, name: String): ChannelsFragment {
            return ChannelsFragment().apply {
                arguments = Bundle().apply {
                    putLong(ARG_PLAYLIST_ID, playlistId)
                    putString(ARG_PLAYLIST_NAME, name)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playlistId = arguments?.getLong(ARG_PLAYLIST_ID) ?: viewModel.selectedPlaylistId
        playlistName = arguments?.getString(ARG_PLAYLIST_NAME) ?: ""
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentChannelsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (playlistName.isNotEmpty()) {
            activity?.title = playlistName
        }

        channelAdapter = ChannelAdapter(
            onChannelClick = { channel -> playChannel(channel) },
            onFavoriteClick = { channel -> viewModel.toggleFavorite(channel) }
        )
        binding.recyclerChannels.adapter = channelAdapter

        // Observe groups for tab creation
        viewModel.getGroupsByPlaylist(playlistId).observe(viewLifecycleOwner) { groups ->
            setupTabs(groups)
        }

        loadChannelsForGroup(ALL_CHANNELS)
    }

    private fun setupTabs(groups: List<String>) {
        binding.tabGroups.removeAllTabs()
        binding.tabGroups.addTab(binding.tabGroups.newTab().setText(ALL_CHANNELS))
        groups.forEach { group ->
            binding.tabGroups.addTab(binding.tabGroups.newTab().setText(group))
        }

        binding.tabGroups.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                selectedGroup = tab.text?.toString() ?: ALL_CHANNELS
                loadChannelsForGroup(selectedGroup)
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun loadChannelsForGroup(group: String) {
        if (group == ALL_CHANNELS) {
            viewModel.getChannelsByPlaylist(playlistId).observe(viewLifecycleOwner) { channels ->
                channelAdapter.submitList(channels)
                binding.emptyState.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
            }
        } else {
            viewModel.getChannelsByGroup(playlistId, group).observe(viewLifecycleOwner) { channels ->
                channelAdapter.submitList(channels)
                binding.emptyState.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun playChannel(channel: Channel) {
        val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_CHANNEL_NAME, channel.name)
            putExtra(PlayerActivity.EXTRA_CHANNEL_URL, channel.url)
            putExtra(PlayerActivity.EXTRA_CHANNEL_LOGO, channel.logoUrl)
        }
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
