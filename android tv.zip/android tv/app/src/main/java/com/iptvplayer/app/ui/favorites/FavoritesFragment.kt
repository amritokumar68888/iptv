package com.iptvplayer.app.ui.favorites

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.iptvplayer.app.databinding.FragmentFavoritesBinding
import com.iptvplayer.app.data.model.Channel
import com.iptvplayer.app.ui.channels.ChannelAdapter
import com.iptvplayer.app.ui.main.MainViewModel
import com.iptvplayer.app.ui.player.PlayerActivity

class FavoritesFragment : Fragment() {

    private var _binding: FragmentFavoritesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: ChannelAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFavoritesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ChannelAdapter(
            onChannelClick = { channel -> playChannel(channel) },
            onFavoriteClick = { channel -> viewModel.toggleFavorite(channel) }
        )
        binding.recyclerFavorites.adapter = adapter

        viewModel.favorites.observe(viewLifecycleOwner) { channels ->
            adapter.submitList(channels)
            binding.emptyState.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun playChannel(channel: Channel) {
        val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_CHANNEL_NAME, channel.name)
            putExtra(PlayerActivity.EXTRA_CHANNEL_URL, channel.url)
            putExtra(PlayerActivity.EXTRA_CHANNEL_LOGO, channel.logoUrl)
        }
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
