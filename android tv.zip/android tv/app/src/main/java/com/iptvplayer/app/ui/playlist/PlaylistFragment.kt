package com.iptvplayer.app.ui.playlist

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.iptvplayer.app.R
import com.iptvplayer.app.databinding.FragmentPlaylistBinding
import com.iptvplayer.app.data.model.Playlist
import com.iptvplayer.app.ui.channels.ChannelsFragment
import com.iptvplayer.app.ui.main.MainViewModel

class PlaylistFragment : Fragment() {

    private var _binding: FragmentPlaylistBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: PlaylistAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentPlaylistBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = PlaylistAdapter(
            onPlaylistClick = { playlist -> openPlaylist(playlist) },
            onRefreshClick = { playlist -> refreshPlaylist(playlist) },
            onDeleteClick  = { playlist -> confirmDelete(playlist) }
        )

        binding.recyclerPlaylists.adapter = adapter

        viewModel.playlists.observe(viewLifecycleOwner) { playlists ->
            adapter.submitList(playlists)
            binding.emptyState.visibility = if (playlists.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.fabAddPlaylist.setOnClickListener {
            startActivity(Intent(requireContext(), AddPlaylistActivity::class.java))
        }
    }

    private fun openPlaylist(playlist: Playlist) {
        viewModel.selectPlaylist(playlist.id)
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, ChannelsFragment.newInstance(playlist.id, playlist.name))
            .addToBackStack(null)
            .commit()
    }

    private fun refreshPlaylist(playlist: Playlist) {
        Toast.makeText(requireContext(), getString(R.string.refreshing), Toast.LENGTH_SHORT).show()
        viewModel.refreshPlaylist(playlist) { result ->
            activity?.runOnUiThread {
                if (result.isSuccess) {
                    Toast.makeText(requireContext(), getString(R.string.refresh_success), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), getString(R.string.refresh_failed, result.exceptionOrNull()?.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun confirmDelete(playlist: Playlist) {
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.delete_playlist)
            .setMessage(getString(R.string.delete_playlist_confirm, playlist.name))
            .setPositiveButton(R.string.delete) { _, _ -> viewModel.deletePlaylist(playlist) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
